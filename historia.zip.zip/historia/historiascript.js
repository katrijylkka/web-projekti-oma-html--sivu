/* Tähän väliin tulee Historia osion Java-script  */

/*Pelin runko*/

/* Tähän määritelty palautteet */

const palauteYks= "Vastaathan kysymyksiin, ennen visan palauttamista";
const palauteKaks= "Pisteet: 1/5     Vaatii hiomista";
const palauteKolme= "Pisteet: 2/5     Vaatii hiomista";
const palauteNelja= "Pisteet 3/5     Ihan Jees! Pystytkö petraamaan?";
const palauteViis = "Pisteet 4/5     Fiksu Muksu!";
const palauteKuus = "Pisteet 5/5     Todelinen Einstein!";

/* Tässä funktio */ 

function check(){

	var question1 = document.quiz.question1.value;
	var question2 = document.quiz.question2.value;
	var question3 = document.quiz.question3.value;
  	var question4 = document.quiz.question4.value;
  	var question5 = document.quiz.question4.value;
	var correct = 0;

// Oikeiden vastausten määrittely

	if (question1 == "turku") {
		correct++;
}
	if (question2 == "markka") {
		correct++;
}	
	if (question3 == "tuntematon") {
		correct++;
	}
  if (question4 == "svinhufvud") {
		correct++;
	}
  if (question5 == "vuosi") {
		correct++;
	}
	
	var pictures = ["../historia/images/odotan.gif", "../historia/images/fail.gif", "../historia/images/ok.gif", "../historia/images/bravo.gif", "../historia/images/goodjob.gif" ]
	var messages = ["Vastaathan kysymyksiin, ennen visan palauttamista", "Vastasit vain pariin kysymykseen oikein, vaatii petraamista", "Ihan ok, mutta pystytkö parempaan?", "Hienoa!", "Loisto suoritus!" ]
	var score;

	 if (correct == 0) {
	score = 0;
	}


	if (correct > 0 && correct < 3 ) {
	score = 1;
	}
  

  	if (correct == 3) {
    score = 2;
	  }

	if (correct == 4) {
		score = 3;
	}  

	if (correct == 5) {
		score == 4; 
}

	document.getElementById("after_submit").style.visibility = "visible";

	document.getElementById("message").innerHTML = messages[score];
	document.getElementById("number_correct").innerHTML =  correct;
	document.getElementById("picture").src = pictures[score];
}
